
rootProject.name = "PRUEBA5"

